/*package tda_red�finition;

import java.util.Iterator;

import tda_red�finition.exceptions.ListePleineException;
import tda_red�finition.exceptions.RangInvalideException;

public class ListeTableauCirculaire<E> extends ListeAbstraite<E> implements
		Liste<E> {
	protected static final int MAXELEM = 100;
	protected int lg, tete, queue;

	protected E[] �l�ments;

	public ListeTableauCirculaire() {
		this(MAXELEM);
	}

	public ListeTableauCirculaire(int n) {
		�l�ments = (E[]) new Object[n];
	}

	@Override
	public int longueur() {
		return lg;
	}

	@Override
	public E i�me(int r) throws RangInvalideException { // complexit� en O(1)
		if (r < 1 || r > lg)
			throw new RangInvalideException();
		return �l�ments[(tete + r - 1) % �l�ments.length];
	}

	@Override
	public void supprimer(int r) throws RangInvalideException {
		// complexit� en O(n) mais meilleur que ListeTable dans les pires cas
		if (r < 1 || r > lg)
			throw new RangInvalideException();
		if (r == lg) // supprimer le dernier �l�ment
			queue = queue == 0 ? �l�ments.length - 1 : --queue;
		else {
			if (r == 1) // supprimer le premier �l�ment
				tete = tete == �l�ments.length - 1 ? 0 : ++tete;
			else {
				// d�caler les �l�ments
				for (int i = tete + r; i < lg + tete; i++) {
					// i>0
					�l�ments[(i - 1) % �l�ments.length] = �l�ments[i
							% �l�ments.length];
					queue = queue == 0 ? �l�ments.length - 1 : --queue;
				}
			}
		}
		lg--;
	}

	@Override
	public void ajouter(int r, E e) throws RangInvalideException {
		// complexit� en O(n) mais meilleur que ListeTable dans les pires cas
		if (lg == �l�ments.length)
			throw new ListePleineException();
		if (r < 1 || r > lg + 1)
			throw new RangInvalideException();
		if (r == lg + 1) { // ajouter en queue
			�l�ments[queue] = e;
			queue = queue == �l�ments.length - 1 ? 0 : ++queue;
		} else {
			if (r == 1) { // ajout en t�te
				tete = tete == 0 ? �l�ments.length - 1 : --tete;
				�l�ments[tete] = e;
			} else {
				// d�caler les �l�ments
				for (int i = lg + tete; i >= r + tete; i--) {
					// i>0
					�l�ments[i % �l�ments.length] = �l�ments[(i - 1)
							% �l�ments.length];
				}
				// tete + r-1 est l'indice d'insertion
				�l�ments[r - 1] = e;
				queue = queue == �l�ments.length - 1 ? 0 : ++queue;
			}
		}

		lg++;
	}

	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

}
*/