package tda_red�finition.exceptions;

public class SommetException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SommetException() {
		super();
	}

}