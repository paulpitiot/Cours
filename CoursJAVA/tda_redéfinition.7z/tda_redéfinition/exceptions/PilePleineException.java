package tda_red�finition.exceptions;

public class PilePleineException extends RuntimeException {

	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;

	public PilePleineException() {
		super();
	}
}
