package tda_red�finition;

import java.util.Iterator;

public class TableListeChainee<V, C> implements Table<V, C> extends ListeOrdonneeChainee<Element<V,C>>{

	public TableListeChainee() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Iterator<Element<V, C>> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void ajouter(Element<V, C> e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void supprimer(C cl�) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Element<V, C> rechercher(C cl�) throws Cl�nonTrouv�eException {
		// TODO Auto-generated method stub
		return null;
	}

}
