package tda_red�finition.exceptions;

public class PileVideException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PileVideException() {
		super();
	}
}
