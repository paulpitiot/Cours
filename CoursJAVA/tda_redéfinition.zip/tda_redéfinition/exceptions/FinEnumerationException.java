package tda_red�finition.exceptions;

public class FinEnumerationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FinEnumerationException() {
		super();
	}
}
