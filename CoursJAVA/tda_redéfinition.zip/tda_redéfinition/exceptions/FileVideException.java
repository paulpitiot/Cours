package tda_red�finition.exceptions;

public class FileVideException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FileVideException() {
		super();
	}

}
