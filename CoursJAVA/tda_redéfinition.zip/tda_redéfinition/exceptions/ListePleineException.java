package tda_red�finition.exceptions;

public class ListePleineException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ListePleineException() {
		super();
	}
}
