package tda_red�finition.exceptions;

public class DequeVideException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DequeVideException() {
		super();
	}

}
