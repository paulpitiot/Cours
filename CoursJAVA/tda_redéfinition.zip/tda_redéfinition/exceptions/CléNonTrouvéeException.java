package tda_red�finition.exceptions;

public class Cl�NonTrouv�eException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Cl�NonTrouv�eException() {
		super();
	}

}
